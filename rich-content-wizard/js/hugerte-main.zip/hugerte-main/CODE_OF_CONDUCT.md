# HugeRTE Code of conduct

It's very simple:
- Have some common sense
- Don't use bad language (curses etc.). I mean really, no.
- Some sense of humor is good, but not if it's about religion and of course, jokes may not use bad language
- Be friendly (but you don't need to be too friendly and you may make angry jokes about errors)
- Don't talk about non-children topics

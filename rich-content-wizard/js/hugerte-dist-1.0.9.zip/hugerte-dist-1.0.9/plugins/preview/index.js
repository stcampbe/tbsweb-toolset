// Exports the "preview" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/preview')
//   ES2015:
//     import 'hugerte/plugins/preview'
require('./plugin.js');
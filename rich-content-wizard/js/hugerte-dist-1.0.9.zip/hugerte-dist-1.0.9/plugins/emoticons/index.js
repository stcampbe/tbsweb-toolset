// Exports the "emoticons" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/emoticons')
//   ES2015:
//     import 'hugerte/plugins/emoticons'
require('./plugin.js');
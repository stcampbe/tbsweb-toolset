// Exports the "image" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/image')
//   ES2015:
//     import 'hugerte/plugins/image'
require('./plugin.js');
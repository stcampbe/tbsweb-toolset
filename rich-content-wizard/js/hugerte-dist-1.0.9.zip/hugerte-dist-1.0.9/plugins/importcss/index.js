// Exports the "importcss" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/importcss')
//   ES2015:
//     import 'hugerte/plugins/importcss'
require('./plugin.js');
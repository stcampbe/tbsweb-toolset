// Exports the "autosave" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/autosave')
//   ES2015:
//     import 'hugerte/plugins/autosave'
require('./plugin.js');
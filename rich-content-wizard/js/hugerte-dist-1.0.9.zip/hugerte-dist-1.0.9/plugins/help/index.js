// Exports the "help" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/help')
//   ES2015:
//     import 'hugerte/plugins/help'
require('./plugin.js');
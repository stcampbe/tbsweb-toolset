// Exports the "fullscreen" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/fullscreen')
//   ES2015:
//     import 'hugerte/plugins/fullscreen'
require('./plugin.js');
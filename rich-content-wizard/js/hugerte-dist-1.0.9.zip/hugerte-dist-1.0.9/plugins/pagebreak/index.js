// Exports the "pagebreak" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/pagebreak')
//   ES2015:
//     import 'hugerte/plugins/pagebreak'
require('./plugin.js');
// Exports the "template" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/template')
//   ES2015:
//     import 'hugerte/plugins/template'
require('./plugin.js');
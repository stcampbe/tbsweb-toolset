// Exports the "table" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/table')
//   ES2015:
//     import 'hugerte/plugins/table'
require('./plugin.js');
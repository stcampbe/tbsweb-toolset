// Exports the "code" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/code')
//   ES2015:
//     import 'hugerte/plugins/code'
require('./plugin.js');
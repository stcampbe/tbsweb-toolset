// Exports the "autoresize" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/autoresize')
//   ES2015:
//     import 'hugerte/plugins/autoresize'
require('./plugin.js');
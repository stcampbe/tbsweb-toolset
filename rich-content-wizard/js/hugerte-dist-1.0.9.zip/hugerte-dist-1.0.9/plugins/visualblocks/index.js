// Exports the "visualblocks" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/visualblocks')
//   ES2015:
//     import 'hugerte/plugins/visualblocks'
require('./plugin.js');
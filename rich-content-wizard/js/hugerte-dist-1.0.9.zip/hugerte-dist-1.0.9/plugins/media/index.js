// Exports the "media" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/media')
//   ES2015:
//     import 'hugerte/plugins/media'
require('./plugin.js');
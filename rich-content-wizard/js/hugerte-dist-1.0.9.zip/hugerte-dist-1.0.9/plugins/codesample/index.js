// Exports the "codesample" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/codesample')
//   ES2015:
//     import 'hugerte/plugins/codesample'
require('./plugin.js');
// Exports the "charmap" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/charmap')
//   ES2015:
//     import 'hugerte/plugins/charmap'
require('./plugin.js');
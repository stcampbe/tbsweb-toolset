// Exports the "insertdatetime" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/insertdatetime')
//   ES2015:
//     import 'hugerte/plugins/insertdatetime'
require('./plugin.js');
// Exports the "visualchars" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/visualchars')
//   ES2015:
//     import 'hugerte/plugins/visualchars'
require('./plugin.js');
// Exports the "accordion" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/accordion')
//   ES2015:
//     import 'hugerte/plugins/accordion'
require('./plugin.js');
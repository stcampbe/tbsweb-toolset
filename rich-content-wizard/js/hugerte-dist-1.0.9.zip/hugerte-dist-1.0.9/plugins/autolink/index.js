// Exports the "autolink" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/autolink')
//   ES2015:
//     import 'hugerte/plugins/autolink'
require('./plugin.js');
// Exports the "directionality" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/plugins/directionality')
//   ES2015:
//     import 'hugerte/plugins/directionality'
require('./plugin.js');
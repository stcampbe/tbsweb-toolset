// Exports the "silver" theme for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/themes/silver')
//   ES2015:
//     import 'hugerte/themes/silver'
require('./theme.js');
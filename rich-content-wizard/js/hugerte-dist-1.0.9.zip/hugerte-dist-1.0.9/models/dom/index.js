// Exports the "dom" model for usage with module loaders
// Usage:
//   CommonJS:
//     require('hugerte/models/dom')
//   ES2015:
//     import 'hugerte/models/dom'
require('./model.js');